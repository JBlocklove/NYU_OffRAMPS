# RAMPS-1.4_KiCad
RepRap Arduino Mega Pololu Shield 1.4 Schematic and PCB for KiCAD  
https://reprap.org/wiki/Arduino_Mega_Pololu_Shield
